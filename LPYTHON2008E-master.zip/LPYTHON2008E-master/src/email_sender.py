#
# smtplib
import smtplib
import ssl

if __name__ == '__main__':
    context = ssl.create_default_context()
    SUBJECT = 'PYTHON TUTORIAL'
    TEXT = 'PYTHON MAIL'
    message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.ehlo()
    #server.starttls(context=context)
    server.ehlo()
    server.login('username', 'password')
    server.sendmail(
        'tien.nguyenanh94@gmail.com',
        'tien.nguyenanh94@gmail.com',
        message
    )
    server.quit()
