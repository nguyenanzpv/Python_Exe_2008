#
import time
import resource


if __name__ == '__main__':
    # samples = list(range(1, 10000000000))
    start = time.process_time()
    resource_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    results = []
    for factor in range(1, 10000000):
        results.append(factor ** 2)
    resource_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    end = time.process_time()
    print("Duration: {}".format(end - start))
    print("memory: {}".format(resource_after - resource_before))

    start = time.process_time()
    resource_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    samples = range(1, 10000000)
    power = lambda x : x ** 2
    results = map(power, samples)
    resource_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    end = time.process_time()
    print("Duration: {}".format(end - start))
    print("memory: {}".format(resource_after - resource_before))
    # results_list = []
    # for number in results:
    #     results_list.append(number)
    # print(len(results_list))
    # print(results_list[3])
