#
import time
import resource

def power(numbers):
    results = []
    for number in numbers:
        results.append(number ** 2)
    return results

def power_yield(numbers):
    for number in numbers:
        yield number ** 2

if __name__ == '__main__':
    numbers = list(range(1, 10000000 + 1))

    # start = time.process_time()
    # resource_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # sq_numbers = power(numbers)
    # end = time.process_time()
    # resource_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # print("Duration: {}".format(end - start))
    # print("memory: {}".format(resource_after - resource_before))
    #
    # start = time.process_time()
    # resource_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # sq_numbers = power_yield(numbers)
    # end = time.process_time()
    # resource_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # print("Duration: {}".format(end - start))
    # print("memory: {}".format(resource_after - resource_before))

    start = time.process_time()
    resource_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    sq_numbers = [number ** 2 for number in numbers]
    end = time.process_time()
    resource_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    print("Duration: {}".format(end - start))
    print("memory: {}".format(resource_after - resource_before))

    start = time.process_time()
    resource_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    sq_numbers = (number ** 2 for number in numbers)
    end = time.process_time()
    resource_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    print("Duration: {}".format(end - start))
    print("memory: {}".format(resource_after - resource_before))
