
class Person:
    def __init__(self, id, name, age):
        self.id = id
        self.name = name
        self.age = age

    def __str__(self):
        return "(" + str(self.id) + "," + self.name + ", " + str(self.age) + ")"

class Student(Person):
    def __init__(self, id, name, age, total_credit, duration):
        super().__init__(id, name, age)
        self.total_credit = total_credit
        self.duration = duration

    def __str__(self):
        return "(" + str(self.id) + ", " + self.name + ", " + \
               str(self.age) + ", " + str(self.duration) + ", " \
               + str(self.total_credit) + ")"

class Staff(Person):
    def __init__(self, id, name, age, position, salary):
        super().__init__(id, name, age)
        self.position = position
        self.salary = salary

    def __str__(self):
        return "(" + str(self.id) + ", " + self.name + ", " + \
               str(self.age) + ", " + str(self.position) + ", " \
               + str(self.salary) + ")"

if __name__ == '__main__':
    person = Person(1, 'nguyen', 20)
    print(person)
    student = Student(2, 'ha', 23, 34, 2)
    print(student)
    staff = Staff(2, 'ha', 23, 'president', 2000)
    print(staff)
