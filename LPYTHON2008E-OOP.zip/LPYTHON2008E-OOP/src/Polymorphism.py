#
class Animal(object):
    def __init__(self, name, gender):
        self.name = name
        self.gender = gender

    def say(self):
        raise NotImplementedError()
        #pass

class Dog(Animal):
    def __init__(self, name, gender):
        super().__init__(name, gender)
        self.race = 'dog'

    def say(self):
        return 'I am a {} dog'.format(self.gender)

class Cat(Animal):
    def __init__(self, name, gender):
        super().__init__(name, gender)
        self.race = 'cat'

    def say(self):
        return 'I am a {} cat'.format(self.gender)

if __name__ == '__main__':
    animal = Animal('lucky', 'male')
    #print(animal.say())
    animal = Dog('lucky', 'male')
    print(animal.say())
    animal = Cat('lucky', 'male')
    print(animal.say())
