"""
Inputs:
=======
    +) Input serveral test cases: do not know the number of test cases
        in advance
        -) 1_st line contains N: number of love mobiles
        -) 2_nd line           : numbers 1 to N in an arbitrary order
    +) Input ends with number 0

Outputs:
========
    +) For each test case, print "yes" if can re-order the numbers 1 to N with
        the help of the side street. Otherwise, print "no"

Descriptions
============
    +) Given list of numbers: 1 to N in an arbitray order
    +) The list of numbers follow "queue rule": FIRST IN FIRST OUT
    +) Using another stack  "side stack" to re-order the queue of numbers
"""

if __name__ == '__main__':
    while True:
        num_strucks = int(input())
        if num_strucks == 0:
            break
        strucks = list(map(int, input().split()))
        index = 0
        counter = 1
        side_stack = []
        while index < num_strucks:
            if strucks[index] == counter:
                counter += 1
                index += 1
            elif len(side_stack) != 0 and side_stack[-1] == counter:
                side_stack.pop()
                counter += 1
            else:
                side_stack.append(strucks[index])
                index += 1

        while len(side_stack) != 0 and side_stack[-1] == counter:
            counter += 1
            side_stack.pop()

        print('yes' if counter == index + 1 else 'no')
