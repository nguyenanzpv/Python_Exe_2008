#
class Salary(object):
    def __init__(self, pay, bonus):
        self.pay = pay
        self.bonus = bonus

    def get_anual_salary(self):
        return (self.pay * 12) + self.bonus


class Employee(object):
    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary

    def get_total_salary(self):
        return self.salary.get_anual_salary()

if __name__ == '__main__':
    name = 'Gimli'
    age = 27
    pay = 9000
    bonus = 5000
    salary = Salary(pay, bonus)
    employee = Employee(name, age, pay, bonus)
    print(employee.get_total_salary())
