
with open('../data/poem.txt', 'r') as file:
    for line in file:
        print(line.strip())


