
with open('../data/new_file.txt', 'r+') as file:
    file.write('This is the lecture 5:  new line 5\n')
    file.write('This is the lecture 5:  new line 6\n')
    print(file.readline())


