
import sys

while True:
    print("I am here")
    sys.exit()

print("I am outside")

