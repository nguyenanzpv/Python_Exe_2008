

file = open('../data/poem.txt', 'r')
print(file.read())
file.close()
