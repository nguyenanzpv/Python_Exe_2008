
with open('../data/poem.txt', 'r') as file:
    print(file.read())
