
from prime import prime_handler

def find_max(arrs):
    
    max_prime = 0
    for element in arrs:
        if prime_handler.is_prime(element):
            if element > max_prime:
                max_prime = element
    return max_prime

if __name__ == '__main__':
    arrs = list(map(int, input("Enter arrs: ").split()))
    print("Max prime: ", find_max(arrs))
