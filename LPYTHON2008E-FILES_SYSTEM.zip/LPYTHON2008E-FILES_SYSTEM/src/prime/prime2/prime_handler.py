

def is_prime(number):
    for factor in range(2, number):
        if number % factor == 0:
            return False
    return True
