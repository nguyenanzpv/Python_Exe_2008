from .prime2 import prime_handler

