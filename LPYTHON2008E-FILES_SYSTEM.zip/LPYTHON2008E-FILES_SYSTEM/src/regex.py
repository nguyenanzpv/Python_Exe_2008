#
import re

#example 1
pattern = re.compile("\w")
string_input = "She is so beautiful"
result = pattern.match(string_input)
print(result.group())

#example 2
pattern = re.compile("\w+")
string_input = "She is so beautiful"
result = pattern.match(string_input)
print(result.group())

#example 3
pattern = re.compile("\w+")
string_input = "She is so beautiful"
result = pattern.findall(string_input)
print(result)

#example 4
line = "dance more"
pattern = re.compile("[^\d+]")
result = pattern.match(line)
print(result.group())

#example 5
line = "dance more"
pattern = re.compile("^\d+")
result = pattern.match(line)
print(result.group())
