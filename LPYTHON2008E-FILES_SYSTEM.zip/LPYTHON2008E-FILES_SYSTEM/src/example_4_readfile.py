

with open('../data/poem.txt', 'r') as file:
    data = file.readlines()

print(data)
