#
import string

ASCII_LETTERS = '0123456789' + string.ascii_letters

def valid_letter(letter):
    return letter in ASCII_LETTERS or letter == '.' or letter == '_'

def validate_email(email):
    segments = email.split('@')
    if len(segments) > 2:
        return False
    prefix, postfix = segments
    for char in prefix:
        if not valid_letter(char):
            print(char)
            return False
    for char in postfix:
        if not valid_letter(char):
            print(char)
            return False
    return True
if __name__ == '__main__':
    email = input("Enter email: ")
    if validate_email(email):
        print('Valid email')
    else:
        print('NOT valid email')
