#
def is_prime(number):
    for factor in range(2, number):
        if number % factor == 0:
            return False
    return True

if __name__ == '__main__':
    number = int(input("Enter a number"))
    if is_prime(number):
        print("Yes, it is")
    else:
        print("No, it is not")

